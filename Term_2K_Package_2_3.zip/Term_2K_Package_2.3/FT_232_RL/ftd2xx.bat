implib -c ftd2xx.lib ftd2xx.dll
tdump ftd2xx.lib > ftd2xx.rpt

